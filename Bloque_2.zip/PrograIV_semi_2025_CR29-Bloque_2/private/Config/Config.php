<?php
include('../../Conexion/DB.php');
$conexion = new DB('mysql:host=localhost;dbname=db_sistema_academico', 
    'root', '');
?>